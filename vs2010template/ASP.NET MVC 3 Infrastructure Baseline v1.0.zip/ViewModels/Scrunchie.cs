﻿using System;

namespace $safeprojectname$.ViewModels
{
    public class Scrunchie
    {
        public string Name { get; set; }
        public DateTime Stamp { get; set; }
        public decimal Price { get; set; }
        public decimal Cost { get; set; }
        public int Sold { get; set; }
    }
}