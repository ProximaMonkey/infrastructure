﻿using System.$safeprojectname$.Mvc;

namespace $safeprojectname$.Controllers
{
    public class ZenGardenController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CoLtd()
        {
            return View();
        }

        public ActionResult SilentStrength()
        {
            return View();
        }
    }
}
