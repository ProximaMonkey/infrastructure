﻿using System.$safeprojectname$.Mvc;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Translations()
        {
            return View();
        }

        public ActionResult ZenGarden()
        {
            return View();
        }
    }
}
