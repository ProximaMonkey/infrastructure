﻿namespace $safeprojectname$.Controllers
{
    public class with_a_zen_garden_controller
    {
    }
}
