﻿namespace $safeprojectname$.Controllers
{
    public class with_a_home_controller
    {

    }
}
